---
name: change-existing-software
description: 接手、修复或扩展已有软件，定位真实调用路径，设计兼容的增量并验证旧行为。给现有产品增加新能力时也适用。
---

沿真实入口查调用者、输入和现有测试。用户要理解时交回证据；用户已要求实施时，定位后直接修改并验证。普通仓库只借用 OpenSpec 的探索方法。已有 OpenSpec 规格、store 或 change 时遵守该项目的原生流程；仅在明确进入其探索模式时使用 [Explore 原文](references/explore.md)。

既有产品增加新能力时，先确定用户动作、新结果和失败行为；设计尚不清楚时借用 [需求规格模板](../build-from-requirements/references/spec-template.md) 的相应部分，再沿原接口增量接入。修复故障先复现反例，同时保住旧调用者。

对当前候选核实际文件差异，运行能区分新旧行为的入口测试，记录结果和未验范围。需要模型协作或恢复时读[执行与交接](../build-from-requirements/references/team.md)。
