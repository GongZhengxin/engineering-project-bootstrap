---
name: rebuild-from-reference
description: 从网站、软件、截图或录屏的可观察行为重建目标界面。向既有产品加入参考交互时也适用。
---

记录参考的视口、状态、动作、实际结果和截图。只有静态图时注明未观察到的交互。优先用已有浏览器工具或 Playwright。既有产品内重建功能时，用[增量开发](../change-existing-software/SKILL.md)定位集成入口与旧行为，设计不清楚时先确定用户场景。

同视口实际操作候选，检查状态、键盘、可访问名称和截图差异；保留阈值、候选版本和失败样例。按需用现有视觉技能。评审者须收到真实参考图与候选图。需要协作或恢复时读[执行与交接](../build-from-requirements/references/team.md)。
