---
name: build-from-requirements
description: 根据需求设计并交付新的软件能力。适用于从零建设，也适用于既有产品里尚未定义使用方式的功能设计。
---

先确定用户要完成的动作、成功结果、异常情形和关键设计决定。按需使用 [Spec Kit 规格模板](references/spec-template.md)。小工具可写成一段验收约定。已有产品新增能力时，同时沿[增量开发](../change-existing-software/SKILL.md)查现有入口、兼容性和依赖；已有源码本身不能决定设计范围。

实现一个可操作的纵向增量。用 [Superpowers 完成前验证](references/verification.md) 核本次真实差异、可执行测试和实际入口的结果；注明未验行为。需要协作或恢复时读[执行与交接](references/team.md)。
